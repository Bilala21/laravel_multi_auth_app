to make system functional 
    1.run command composer install or composer update
    2.run command php artisan migrate
    3 For admin login hit the url "admin/login"
