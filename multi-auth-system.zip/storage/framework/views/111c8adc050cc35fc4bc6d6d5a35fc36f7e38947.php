<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#"><?php echo e(Auth::guard('web')->user() ? "User Dashboard" :"Home"); ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 justify-content-end w-100 pt-xl-0 pt-lg-0 pt-md-0 pt-3">
                <?php if(Auth::guard('web')->user()): ?>
                <li class="nav-item btn border p-1 btn-sm">
                    <a  href="#" class="nav-link active" aria-current="page"><?php echo e(Auth::guard('web')->user()->name); ?></a>
                </li>
                <?php else: ?>
                    
                <li class="nav-item btn border p-1 btn-sm">
                    <a  href="<?php echo e(route('user.register')); ?>" class="nav-link active" aria-current="page">Sign Up/Sign In</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
   
</nav><?php /**PATH C:\xampp\htdocs\multi-auth-system\resources\views/user/layout/nav-bar.blade.php ENDPATH**/ ?>